import pygame
from OpenGL.GLU import*
from OpenGL.GL import*
from OpenGL.GLUT import*
from pygame.locals import*
from PIL import*
from Acciones import escenario as es
from Acciones import sonido as son
from Acciones import boceto as b
from Acciones import textos as txt
from Acciones import objetosColisiones as oC
from Acciones import iluminacion as lc
from Acciones import colisiones as coli

#Banderas
bandera=0
bandera1=False
instruccion= True
acercaDe=False
activarColi=False

#Mouse y camara
camara_speed = 0.1
rotation_speed = 0.2
mouse_sesivity = 0.1

#Posiciones de la pelota
PosXPelota, PosYPelota,PosZPelota = 10, 17,0 
#Posiciones de la cabeza
PosXCabeza, PosYCabeza,PosZCabeza=0.9,17,0
#Dimensiones cabeza
Cabeza_Height, Cabeza_width, Cabeza_depth=7.5,7.5,7.5
#Posiciones del corazon
PosXCorazon, PosYCorazon, PosZCorazon=-8,8,0
#Posicion del torso
PosXTorso, PosYTorso, PosZTorso=-8,4,0
#Dimensiones del torso
Torso_Height, Torso_width, Torso_depth = 2,2,2
#Altura de los objetos de colision
Obj1_height=1

#Inicialización
pygame.init()
pygame.mixer.init()
display = (700, 600)
pygame.display.set_mode(display, DOUBLEBUF | OPENGL)
pygame.event.set_grab(True)  
pygame.mouse.set_visible(False)
directorio_script = os.path.dirname(os.path.abspath(__file__))

def valoresIniciales():
    global PosXPelota, PosYPelota,PosZPelota, Obj1_height
    global PosXCabeza,PosYCabeza, PosZCabeza,Cabeza_Height
    global Cabeza_width, Cabeza_depth, PosXCorazon
    global PosYCorazon, PosZCorazon, PosXTorso,PosYTorso
    global PosZTorso, Torso_Height,Torso_depth,Torso_width

    PosXPelota, PosYPelota,PosZPelota = 10, 17,0 
    Obj1_height=1
    PosXCabeza, PosYCabeza,PosZCabeza=0.9,17,0
    Cabeza_Height, Cabeza_width, Cabeza_depth=7.5,7.5,7.5
    PosXCorazon, PosYCorazon, PosZCorazon=-8,8,0
    PosXTorso, PosYTorso, PosZTorso=-8,4,0
    Torso_Height, Torso_width, Torso_depth = 2,2,2

def ventanaInicial():
    gluPerspective(60, (display[0] / display[1]), 0.1, 50.0)
    glTranslatef(0, 0, -5)  # Ajuste de cámara inicial para ver los objetos
    glOrtho(0, 30, 0, 30, 0, 6)

def pelota(movX,movY): 
    global PosXPelota, PosYPelota
    PosXPelota=PosXPelota+movX
    PosYPelota=PosYPelota+movY
    glEnable(GL_DEPTH_TEST)
    glPushMatrix()
    glTranslatef(PosXPelota,PosYPelota,PosZPelota)
    lc.iluminacion()
    oC.BolaDisco('Imagenes\pelota.png',2,40,40)
    glDisable(GL_LIGHTING)
    glDisable(GL_LIGHT0)
    glPopMatrix()
      
def corazon(movX2, movY2):
    global PosXCorazon, PosYCorazon
    PosXCorazon=PosXCorazon+movX2
    PosYCorazon=PosYCorazon+movY2
    glEnable(GL_DEPTH_TEST)
    glPushMatrix()
    glTranslatef(PosXCorazon,PosYCorazon,PosZCorazon)
    lc.iluminacion()
    glColor3f(1,0,0)
    oC.corazon()
    glDisable(GL_LIGHTING)
    glDisable(GL_LIGHT0)
    glPopMatrix()


if __name__ == "__main__":
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    ventanaInicial()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:  
                 son.sonido('Sonido\sonidoFijo.wav')

                if event.key == pygame.K_o:
                    son.stopsonido()
                
                if event.key==pygame.K_ESCAPE:
                    pygame.quit()
                    quit()
                if event.key==pygame.K_2:
                    son.stopsonido()
                    bandera=1
                    son.sonido('Sonido\sonido1.wav')
                if event.key==pygame.K_1:
                    bandera=0
                if event.key==pygame.K_3:
                    son.stopsonido()
                    bandera=2
                    son.sonido('Sonido\sonido2.wav')
                if event.key==pygame.K_4:
                    son.stopsonido()
                    bandera=3
                    son.sonido('Sonido\sonido3.wav')
                if event.key==pygame.K_5:
                    son.stopsonido()
                    bandera=4
                    bandera5=False
                    son.sonido('Sonido\sonido4.wav')
                if event.key==pygame.K_6:
                    son.stopsonido()
                    bandera=5
                    son.sonido('Sonido\sonido5.wav')
                ##Feliz
                if event.key==pygame.K_7:
                    son.stopsonido()
                    bandera=6
                    son.sonido('Sonido\sonido6.wav')
                #Triste
                if event.key==pygame.K_8:
                    son.stopsonido()
                    bandera=7
                    son.sonido('Sonido\sonido7.wav')
                #Mover brazos
                if event.key==pygame.K_9:
                    bandera=8
                #Caminar
                if event.key==pygame.K_0:
                    bandera=9
                #Mover brazos 2
                if event.key==pygame.K_z:
                    bandera=10
                #Mover cabeza
                if event.key==pygame.K_x:
                    bandera=11
                #Saltar
                if event.key==pygame.K_c:
                    bandera=12
                #Salto split
                if event.key==pygame.K_v:
                    bandera=13
                #Caer
                if event.key==pygame.K_b:
                    bandera=14
                #Colisiones
                if event.key==pygame.K_n:
                    bandera=15
                    activarColi=not activarColi
                #Instrucciones
                if event.key==pygame.K_i:
                    instruccion = not instruccion
                if event.key==pygame.K_u:
                    acercaDe=not acercaDe
            
        keys = pygame.key.get_pressed()
        if keys[pygame.K_s]:
            glTranslate(0, 0, 0.1)
        if keys[pygame.K_w]:
            glTranslate(0, 0, -0.1)
        if keys[pygame.K_a]:
            glTranslate(0.1, 0, 0)
        if keys[pygame.K_d]:
            glTranslate(-0.1, 0, 0)
        if keys[pygame.K_q]:
            glTranslate(0, -0.1, 0)
        if keys[pygame.K_e]:
            glTranslate(0, 0.1, 0)
        if keys[pygame.K_r]:
            glLoadIdentity()
            ventanaInicial()

        # Movimiento y rotación con el mouse
        x, y = pygame.mouse.get_rel()
        x *= mouse_sesivity
        y *= mouse_sesivity

        if x != 0:
            glRotatef(x, 0, 1, 0)  # Rotación en eje Y para girar la vista horizontalmente
        if y != 0:
            glRotatef(y, 1, 0, 0)  # Rotación en eje X para girar la vista verticalmente

        pygame.mouse.set_pos(display[0] // 2, display[1] // 2)

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glEnable(GL_DEPTH_TEST)
        glPushMatrix() 
        
        if(coli.rombo_collision(PosXCabeza, PosYCabeza, PosZCabeza,Cabeza_width, Cabeza_Height,Cabeza_depth,
            PosXPelota, PosYPelota, PosZPelota,Obj1_height)):
            bandera1=True
            valoresIniciales()

        if(coli.rombo_collision(PosXTorso, PosYTorso, PosZTorso,Torso_width, Torso_Height,Torso_depth,
            PosXCorazon, PosYCorazon, PosZCorazon,Obj1_height)):
               bandera1=False
               valoresIniciales()
         
        if bandera==0:
            b.original()
            es.draw_e('Imagenes\descarga_resized_op.jpeg')   
        if bandera==1:
            b.asustado()
            es.draw_e('Imagenes/fondo5.jpg')
        if bandera==2:
            b.molesto()
            es.draw_e('Imagenes/fondo4.jpg')
        if bandera==3:
            b.preocupado()
            es.draw_e('Imagenes/fondo2.jpg')
        if bandera==4:
            b.drawIndiferencia()
            es.draw_e('Imagenes/fondo3.jpg')
        if bandera==5:
            b.sorprendido()
            es.draw_e('Imagenes/fondo6.jpg')
        if bandera==6:
            b.felicidad()
            es.draw_e('Imagenes/fondo7.jpg')
        if bandera==7:
            b.triste()
            es.draw_e('Imagenes/fondo8.jpg')
        if bandera==8:
            b.animaLevantar()
            es.draw_e('Imagenes\descarga_resized_op.jpeg')
        if bandera==9:
            b.animaCaminar()
            es.draw_e('Imagenes\descarga_resized_op.jpeg')
        if bandera==10:
            b.animaBrazo2()
            es.draw_e('Imagenes\descarga_resized_op.jpeg')
        if bandera==11:
            b.animaCabeza()
            es.draw_e('Imagenes\descarga_resized_op.jpeg')
        if bandera==12:
            b.animaBrincar()
            es.draw_e('Imagenes\descarga_resized_op.jpeg')
        if bandera==13:
            b.animaBrincarSplit()
            es.draw_e('Imagenes\descarga_resized_op.jpeg')
        if bandera==14:
            b.animaCaida()
            es.draw_e('Imagenes\descarga_resized_op.jpeg')
        if bandera==15:
            txt.draw_text("Usar flechas del teclado para mover los objetos", -40, 40, -1, 25, 255, 255, 255, 0, 0, 0)
            if(bandera1==False and activarColi==True):
                b.original()
                pelota(0,0)
            if(bandera1==True):
                b.triste()
                corazon(0,0)
            es.draw_e('Imagenes\descarga_resized_op.jpeg')  
        if activarColi:
            if bandera1==False:
                if keys[pygame.K_UP]:
                    pelota(0,1)
                if keys[pygame.K_DOWN]:
                    pelota(0,-1)
                if keys[pygame.K_LEFT]:
                    pelota(-1,0)
                if keys[pygame.K_RIGHT]:
                    pelota(1,0)
            if bandera1==True:
                if keys[pygame.K_UP]:
                    corazon(0,1)
                if keys[pygame.K_DOWN]:
                    corazon(0,-1)
                if keys[pygame.K_LEFT]:
                    corazon(-1,0)
                if keys[pygame.K_RIGHT]:
                    corazon(1,0)
            
        if instruccion:
            txt.draw_text("1:Original  2:Escenario1  3:Escenario2  4:Escenario3 5:Escenario4 ", -40, -10, -1, 25, 255, 255, 255, 0, 0, 0)
            txt.draw_text("6:Escenario5  7:Escenario6  8:Escenario7  9:Mov1  0:Mov2", -40, -15, -1, 25, 255, 255, 255, 0, 0, 0)
            txt.draw_text("z:Mov3  x:Mov4  c:Mov5  v:Mov6  b:Mov7  p:Sonido  o:ApagarSonido", -40, -20, -1, 25, 255, 255, 255, 0, 0, 0)
            txt.draw_text("n:Activar colisiones",20,0,-1,25,255,255,255,0,0,0)
            txt.draw_text("s:Cam(Zo)  w:Cam(Zi)  a:Cam(izq)  d:Cam(der)  q:Cam(Arriba)   ", -40, -25, -1, 25, 255, 255, 255, 0, 0, 0)
            txt.draw_text("e:Cam(Abajo)  r:Cam(Orginal)  i:Instruccion(On/Of)  u:Acerca de:", -40, -30, -1, 25, 255, 255, 255, 0, 0, 0)
        if acercaDe:
            txt.draw_text("Starenka Susana Ortiz Gallegos 22280683", -40, 40, -1, 25, 255, 255, 255, 0, 0, 0)
        

        glPopMatrix() 
    
        pygame.display.flip()
        pygame.time.wait(10)  #
        

